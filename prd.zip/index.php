<?php 
ob_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>STH</title>
  <link rel="stylesheet" href="bower_components/bootstrap/dist/css/bootstrap.min.css">
  <style>
    .container {
			margin: 0 auto;
      padding-top: 100px;
      width: 500px;
    }
		.logout {
			text-align: center;
		}
  </style>
</head>
<body>
  <div class="container">
      <?php
      session_start();
      include('NotORM.php');
      $dbh = new PDO('mysql:host=localhost;dbname=sss', 'root', '');
      $db = new NotORM($dbh);
      $users = ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8', 'a9', 'a10', 'a11', 'a12', 'a13', 'a14', 'a15', 'admin'];
      $passes = Array(
        'a1' => 123,
        'a2' => 123,
        'a3' => 123,
        'a4' => 123,
        'a4' => 123,
        'a5' => 123,
        'a6' => 123,
        'a7' => 123,
        'a8' => 123,
        'a9' => 123,
        'a10' => 123,
        'a11' => 123,
        'a12' => 123,
        'a13' => 123,
        'a14' => 123,
        'a15' => 123,
        'admin' => 10203151000
      );

      if($_SERVER['REQUEST_METHOD'] == 'POST') {
        if(@!$_SESSION['login']) {
          if(@in_array($_POST['username'], $users) && $_POST['password'] == $passes[$_POST['username']]) {
            $_SESSION['login'] = $_POST['username'];
            if($_POST['username'] == 'admin') $_SESSION['admin'] = true;
            header('Location: index.php');
            exit;
          } else {
            echo 'Password is wrong';
          }
        }
      }
      
      if(@$_SESSION['admin']) {
      if(@$_GET['res']) include('result.php');
      else include('admin.php');
        echo '<p class="logout"><a href="logout.php">logout</a></p>';
      } elseif(@$_SESSION['login']) {
        include('fields.php');
        echo '<p class="logout"><a href="logout.php">logout</a></p>';
      } else {
        include('login.php');
      }
      ?>
  </div>
</body>
</html>
