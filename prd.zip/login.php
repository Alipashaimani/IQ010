<div class="panel panel-default">
  <div class="panel-body">
    <h1>Insert your information</h1>
    <form method="post" action="index.php">
      <p>
        <label for="username">Username:</label>
        <input type="text" class="form-control" id="username" name="username">
      </p>
      <p>
        <label for="password">Password:</label>
        <input type="password" class="form-control" id="password" name="password">
      </p>
      <input type="submit" class="btn btn-default" value="login">
    </form>
  </div>
</div>
